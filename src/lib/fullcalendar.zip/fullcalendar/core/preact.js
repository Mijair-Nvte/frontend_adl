export * from 'preact';
export { createPortal } from 'preact/compat';
export { af as createContext, a8 as flushSync } from './internal-common.js';
