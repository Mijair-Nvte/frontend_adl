import { LocaleInput } from '../index.js';

declare const _default: LocaleInput;
//# sourceMappingURL=si-lk.d.ts.map

export { _default as default };
