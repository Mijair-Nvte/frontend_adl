'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var l72 = {
    code: 'ug',
    buttonText: {
        prev: 'ئالدىنقى',
        next: 'كېيىنكى',
        today: 'بۈگۈن',
        year: 'يىل',
        month: 'ئاي',
        week: 'ھەپتە',
        day: 'كۈن',
        list: 'كۈنتەرتىپ',
    },
    allDayText: 'پۈتۈن كۈن',
};

exports["default"] = l72;
