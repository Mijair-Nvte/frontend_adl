import { LocaleInput } from '../index.js';

declare const _default: LocaleInput;
//# sourceMappingURL=eo.d.ts.map

export { _default as default };
