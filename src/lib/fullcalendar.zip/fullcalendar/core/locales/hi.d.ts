import { LocaleInput } from '../index.js';

declare const _default: LocaleInput;
//# sourceMappingURL=hi.d.ts.map

export { _default as default };
