import { LocaleInput } from '../index.js';

declare const _default: LocaleInput;
//# sourceMappingURL=ar-tn.d.ts.map

export { _default as default };
