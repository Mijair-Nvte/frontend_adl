import { PluginDef } from '@fullcalendar/core';

declare const _default: PluginDef;
//# sourceMappingURL=index.d.ts.map

export { _default as default };
